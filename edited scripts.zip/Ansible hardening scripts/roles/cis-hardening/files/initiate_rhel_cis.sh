
sudo su

dir=`pwd`

cd $dir/roles/cis-hardening/files/

sudo sh RHEL7_LBK.sh

